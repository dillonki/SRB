#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm ghostrider --pool rtm.suprnova.cc:6273 --wallet RP15M2tYSy5LJqGX8qWVQXg2MWdMTjxkv5
